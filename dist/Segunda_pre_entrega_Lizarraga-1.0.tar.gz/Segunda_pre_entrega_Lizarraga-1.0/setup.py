from setuptools import setup

setup(
    name="Segunda_pre_entrega_Lizarraga",
    version="1.0",
    description="Programa de compras",
    author="Maximiliano Lizarraga",
    packages=["Segunda_pre_entrega_Lizarraga"]
)